<?php
class peliculaModel
{
    private $db;

    public function __construct($dbConnection)
    {
        $this->db = $dbConnection;
    }

    public function getPeliculas()
    {
        $query = "SELECT * FROM pelicula";
        $result = $this->db->query($query);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getPeliculaById($id)
    {
        $query = "SELECT * FROM pelicula WHERE pelicula_id = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    public function createPelicula($titulo, $gen_id, $anio_lanzamiento, $link_img)
    {
        $query = "INSERT INTO pelicula (titulo, gen_id, anio_lanzamiento, link_img) 
                  VALUES (:titulo, :gen_id, :anio_lanzamiento, :link_img)";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':titulo', $titulo, PDO::PARAM_STR);
        $statement->bindParam(':gen_id', $gen_id, PDO::PARAM_INT);
        $statement->bindParam(':anio_lanzamiento', $anio_lanzamiento, PDO::PARAM_INT);
        $statement->bindParam(':link_img', $link_img, PDO::PARAM_STR);
        $statement->execute();
        return $this->db->lastInsertId();
    }

    public function updatePelicula($id, $titulo, $gen_id, $anio_lanzamiento, $link_img)
    {
        $query = "UPDATE pelicula SET titulo = :titulo, gen_id = :gen_id, 
                  anio_lanzamiento = :anio_lanzamiento, link_img = :link_img
                  WHERE pelicula_id = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':titulo', $titulo, PDO::PARAM_STR);
        $statement->bindParam(':gen_id', $gen_id, PDO::PARAM_INT);
        $statement->bindParam(':anio_lanzamiento', $anio_lanzamiento, PDO::PARAM_INT);
        $statement->bindParam(':link_img', $link_img, PDO::PARAM_STR);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        return $statement->execute();
    }

    public function deletePelicula($id)
    {
        $query = "DELETE FROM pelicula WHERE pelicula_id = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        return $statement->execute();
    }
}
?>
