<!DOCTYPE html>
<html>

<head>
    <title>Crear Película</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="../CSS/style.css">

</head>

<body>
    <div class="container">
        <h1 class="text-center p-3">CREAR PELICULA</h1>
        <form action="create_process.php" method="POST">
            <div class="form-group">
                <label>Titulo:</label>
                <input type="text" name="titulo" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Genero ID:</label>
                <input type="text" name="gen_id" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Año Lanzamiento:</label>
                <input type="text" name="anio_lanzamiento" class="form-control">
            </div>
            <div class="form-group">
                <label>Link Imagen:</label>
                <input type="text" name="link_img" class="form-control">
            </div>
            <br>
            <button type="submit" class="btn btn-primary">Crear</button>
        </form>
    </div>
</body>

</html>
