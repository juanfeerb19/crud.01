<?php
require '../controller/peliculaController.php';

$controller = new PeliculaController();
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $pelicula = $controller->getPeliculaById($id);

    if (!$pelicula) {
        die('Película no encontrada');
    }

    $controller->deletePelicula($id);
    header('Location: index.php');
    exit;
} else {
    die('Id no especificado');
}
?>