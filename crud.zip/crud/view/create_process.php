<?php
require_once '../controller/peliculaController.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $gen_id = $_POST['gen_id'];
    $anio_lanzamiento = $_POST['anio_lanzamiento'];
    $link_img = $_POST['link_img'];

    $controller = new peliculaController();

    $result = $controller->createPelicula($titulo, $gen_id, $anio_lanzamiento, $link_img);

    if ($result) {
        header('Location: index.php');
        exit();
    } else {
        echo 'Error al crear la película';
    }
} else {
    header('Location: index.php');
    exit();
}
