<?php
require_once '../controller/peliculaController.php';
require_once 'peliculaView.php';

$controller = new peliculaController();
$view = new peliculaView();

// Obtener todas las películas
$peliculas = $controller->getPeliculas();
?>

<!DOCTYPE html>
<html>

<head>
    <h1 class="text-center p-3">GESTION DE PELICULAS</h1>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="../CSS/style.css">
    <script>
        function confirmDelete() {
            return confirm("¿Estás seguro de que deseas eliminar esta película?");
        }
    </script>
</head>

<body>
    <div class="container p-4">
        <div class="table-container">
            <table class="table table-hover-columns table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>TITULO</th>
                        <th>GENERO</th>
                        <th>AÑO LANZAMIENTO</th>
                        <th>LINK IMAGEN</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($peliculas as $pelicula) : ?>
                        <tr>
                            <td><?php echo $pelicula['pelicula_id']; ?></td>
                            <td><?php echo $pelicula['titulo']; ?></td>
                            <td><?php echo $pelicula['gen_id']; ?></td>
                            <td><?php echo $pelicula['anio_lanzamiento']; ?></td>
                            <td class="link-imagen"><?php echo $pelicula['link_img']; ?></td>
                            <td class="acciones">
                                <a href="edit.php?id=<?php echo $pelicula['pelicula_id']; ?>" class="btn btn-sm btn-warning">Editar</a>
                                <a href="delete.php?id=<?php echo $pelicula['pelicula_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">Eliminar</i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <a href="create.php" class="btn btn-primary mb-4">Crear Pelicula</a>

        </div>
    </div>
</body>

</html>
