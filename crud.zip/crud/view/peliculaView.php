<?php
class PeliculaView
{
    public function listPeliculas($peliculas)
    {
        foreach ($peliculas as $pelicula) {
            echo "ID: " . $pelicula['pelicula_id'] . "<br>";
            echo "Title: " . $pelicula['titulo'] . "<br>";
            echo "Genre ID: " . $pelicula['gen_id'] . "<br>";
            echo "Release Year: " . $pelicula['anio_lanzamiento'] . "<br>";
            echo "Image Link: " . $pelicula['link_img'] . "<br>";
            echo "<br>";
        }
    }

    public function showMessage($message)
    {
        echo $message;
    }
}
?>
